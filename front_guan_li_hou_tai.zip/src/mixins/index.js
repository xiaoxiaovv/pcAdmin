import tableMixin from './src/tableMixin'
import levelAliasMixin from './src/levelAliasMixin'

export {
  tableMixin,
  levelAliasMixin
}
