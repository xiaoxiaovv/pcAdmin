<template>
  <div class="app-container" v-loading="loading">
    <div class="action-container">
      <el-button icon="el-icon-refresh" size="small" @click="refresh">刷新</el-button>
    </div>
    <el-table
      :data="tableData"
      style="width: 100%"
      @selection-change="handleSelectionChange">
      <el-table-column
        type="selection"
        width="55">
      </el-table-column>
      <el-table-column
        prop="merchantName"
        label="商户名">
      </el-table-column>
      <el-table-column
        prop="merchantAccount"
        label="商户账号">
      </el-table-column>
      <el-table-column label="签约状态">
        <template slot-scope="scope">
          <template v-if="scope.row.signStatus===1">未开通</template>
          <template v-else-if="scope.row.signStatus===2">待审核</template>
          <template v-else-if="scope.row.signStatus===3">签约成功</template>
          <template v-else-if="scope.row.signStatus===4">签约失败</template>
          <template v-else>未知</template>
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        width="600">
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="rooterDeatil(scope.row)">进件资料详情
          </el-button>
          <el-button
            type="text"
            @click="fileSubmit(scope.row)" :disabled="btnLoading">进件资料提交
          </el-button>
          <!--<el-button-->
          <!--type="text"-->
          <!--@click="edithsfFile(scope.row)">惠闪付进件资料-->
          <!--</el-button>-->
          <el-button
            type="text"
            @click="editHsfImgFile(scope.row)">进件图片详情
          </el-button>
          <el-button
            type="text"
            @click="imgFileSubmit(scope.row)" :disabled="btnLoading">进件图片提交
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <pagination
      :total-elements="totalElements"
      :change-callback="getMchInfoList"
      ref="page"></pagination>
  </div>
</template>

<script>
import {
  getMchInfoList,
  hsfPhotoJudge,
  hsfRegister,
  hsfImageRegister
} from '@/modules/thirdMchInfo/agent/api/hsfMerchantInfo'
import pagination from '@/components/pagination/index'

export default {
  components: {pagination},
  name: 'user',
  data () {
    return {
      loading: false,
      btnLoading: false,
      multipleSelection: [], // 选中数据-多选
      totalElements: 0, // 数据条数
      queryList: {
        name: '',
        email: '',
        phone: ''
      }, // 搜素数据
      tableData: [], // 表格数据
      addDialog: false, // 添加模态框

      formLabelWidth: '120px'
    }
  },
  mounted () {
    this.getMchInfoList(1, 10)
  },
  methods: {
    handleSelectionChange (val) {
      this.multipleSelection = val
    },
    handleDelete (row) {
      this.multipleSelection.push(row)
        this.deleteRoles()
    },
    /*
       * 获取列表
       * */
    getMchInfoList (number, pageSize) {
      this.loading = true
        let that = this
        getMchInfoList(number, pageSize).then(response => {
        let data = response.obj
          console.log(data)
          this.totalElements = data.totalElements
          this.tableData = data.content
          //优化显示
          setTimeout(() => {
          that.loading = false
        }, 500)
      }).catch(() => {
        this.loading = false
      })
    },
    // 跳转详情页
    rooterDeatil (data) {
      // console.log(data)
      // query发送ID到详情
      let id = data.merchantId //获取本商户id
        this.$router.push({path: '/thirdMchInfo/agent/views/hsfDetails', query: {id: id}})
    },

    /**
       * 进件资料提交
       */
    fileSubmit: function (data) {
      let id = data.merchantId //获取本商户id
        this.btnLoading = true
        hsfRegister(id).then(res => {
        this.$message.success('资料提交第三方成功')
          this.btnLoading = false
      }).catch(e => {
        this.btnLoading = false
      })
    },

    /**
       * 进件图片资料
       */
    editHsfImgFile (data) {
      let id = data.merchantId //获取本商户id
        let mn = data.merchantName
        this.$router.push({path: '/thirdMchInfo/agent/views/hsfImageIncoming', query: {id: id, n: mn}})
    },

    /**
       * 进件图片资料
       */
    imgFileSubmit: function (data) {
      let id = data.merchantId //获取本商户id
        this.btnLoading = true
        hsfImageRegister(id).then(res => {
        this.$message.success('图片资料提交第三方成功')
          this.btnLoading = false
        setTimeout(() => {
          this.loading = false
        }, 20000)
      }).catch(e => {
        this.btnLoading = false
      })
    },

    // ------------------------------------------------------------------------------------------------------------------------
    /*
     * 刷新
     * */
    refresh () {
      this.$refs.page.refresh()
    },
    /*
      * 搜索
      * */
    search () {
      this.$refs.page.search()
    },
    /*
      * 重置
      * */
    reset () {
      this.queryList = {
        name: '',
        email: '',
        phone: ''
      }
        this.$refs.page.search()
    }
  }
}
</script>

<style scoped>
  body .el-table th.gutter {
    display: table-cell !important;
  }
</style>
