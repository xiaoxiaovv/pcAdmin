export const uploadPrefix = "/fms"   //本模块项目前缀

export const project = "/file"       //本项目名称
