// 版本号
export const version = '5.4.0'

// export const IS_DEV = env.NODE_ENV === 'development'
export const IS_DEV = process.env.NODE_ENV === 'development'
