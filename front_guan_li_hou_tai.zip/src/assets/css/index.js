import './global.scss'
switch (1) {
  default:
    require('./default')
    break
}
