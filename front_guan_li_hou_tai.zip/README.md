# y

> A Vue.js project
##google browser setting
“Cookie 及其他网站数据”，选择 “允许所有 Cookie”， 否则点击“进件”按钮，会报错，显示白板，原因为iframe安全限制问题 https://blog.csdn.net/KamyoChae/article/details/80857232
## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

/dist/
 window.serverUrl = 'http://mamipay.com'
 #忽略文件
 ###从git拉去的文件带'-去掉中文‘的文件需要将'-去掉中文‘删掉来使用该文件，包括根目录的indexDev-去掉中文.html和config/index-去掉中文.js
